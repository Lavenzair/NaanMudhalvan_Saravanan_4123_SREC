from django.apps import AppConfig


class MydjangoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mydjango'
