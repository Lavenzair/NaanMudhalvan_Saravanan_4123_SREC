from django.urls import path
from .views import home, login_view, signup_view, about, service

urlpatterns = [
    path("", home, name = "home"),
    path("login/", login_view, name = "login"),
    path("signup/", signup_view, name = "signup"),
    path("about/", about, name = "about"),
    path("service/",service, name = "service")
]